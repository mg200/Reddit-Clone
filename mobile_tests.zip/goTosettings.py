from main import *
#goToSettings()
goToAccountSettings()