from main import *

def createcommunity():
    