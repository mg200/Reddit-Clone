from main import *
# logout()
login(jimmy_name, jimmy_pass)
#sleep(1)
logout()