from  main import *
goToNavigation()