from main import *
logout()