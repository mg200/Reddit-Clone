from main import *
login(mariam_name, mariam_pass)