from main import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

def upvoteDownvote():
    wait = WebDriverWait(driver, 10)  # Set the maximum wait time in seconds
    
    postPhoteupvote = wait.until(EC.presence_of_element_located((AppiumBy.XPATH, photoPostupvote)))
    postPhoteupvote.click()
    sleep(2)
    postPhoteupvote.click()
    
    postPhotoDownvote = wait.until(EC.presence_of_element_located((AppiumBy.XPATH, photoPostdownvote)))
    postPhotoDownvote.click()
    sleep(2)
    postPhotoDownvote.click()

upvoteDownvote()
